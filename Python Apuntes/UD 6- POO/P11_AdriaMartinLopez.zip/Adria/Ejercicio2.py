import calendar #Importo el calendario
dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]#Creo una lista con los días de la semana
print(dias[calendar.weekday(2020, 2, 19)])#hago una consulta sobre el calendario para la fecha de pedida y lo comparo la salida generada con el array list creado