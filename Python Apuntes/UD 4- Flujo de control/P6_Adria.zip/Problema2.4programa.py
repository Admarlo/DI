orden = input("Deme la orden de comida: ")
print(f"Ha introdido: {orden} ")
print("[Ensalada:] ", sum(orden[i:].startswith("ensalada") for i in range(len(orden)))," [Hamburguesa:]", sum(orden[i:].startswith("hamburguesa") for i in range(len(orden))), " [agua:] ", sum(orden[i:].startswith("Agua") for i in range(len(orden))))
