def gcdIter(a,b):
    if(a|b <= 0):
        return None
    while(!=0):
        (a,b)=(b,a%b)
    return a
    
