cade = input("Deme una cadena: ")
print(f"La cadena introducida es: {cade} ")
print("El término bob aparece", sum(cade[i:].startswith("bob") for i in range(len(cade))), " veces")    
