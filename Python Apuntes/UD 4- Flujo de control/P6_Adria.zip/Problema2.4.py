def item_order(orden):
    ens=order.count(" ensalada ")
    hamb=order.count(" hamburguesa ")
    agu=order.count(" agua ")
    return"[Ensalada:] "+str(ens)+" [Hamburguesa:] "+str(ham)+" [Agua:] "+str(agu)
