def iterpower(base,exp)
    if(exp==0)
        return 1
    if(exp<0):
        return None
    sol=base
    for i in range(exp-1):
        sol=sol*base
    return sol
    
    
