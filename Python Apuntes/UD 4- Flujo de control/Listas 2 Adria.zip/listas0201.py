#Escriba un programa que permita crar una lista y que a  continuación,
#ordene la lista por orden alfabético

#Creo la lista y la evaluo para que tenga valores mayores de cero.
l=input("Dígame cuántas palabras tiene la lista: ")
lista=list()
if(int(l)<=0):
    print('¡¡¡La lista tiene que contener más de 1 valor!!!')
else:
#Recorro la lista para agragar valores.
    for i in range(int(l)):
        inserte=input('Dígame la palabra '+str(i+1)+' :')
        lista.append(inserte)
#Visualización de la lista y de la lista ordenada
    print('La lista creada es: ',lista)
    print('La lista ordenada es: '+str(sorted(lista)))
