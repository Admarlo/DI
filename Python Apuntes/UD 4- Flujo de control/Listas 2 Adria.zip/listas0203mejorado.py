n=int(input('Deme un número: '))
c = [i for i in range(1,(n+1)) if (i%2!=0 or i==2) and (i%3!=0 or i==3) and (i%5!=0 or i==5) and (i%7!=0 or i==7)]
print ('Primos hasta '+str(n)+' : ',c)
