#Escriba un programa que pida un número y a continuación escriba la lista de
#todos los divisores del número (incluidos el uno y él mismo)

n=int(input('Digame un número: '))
listaDiv=list()
if(n<0):
    print("El número insertado tiene que ser mayor de cero")
elif(n==0):
    print("Cero tiene infinitos divisores")
else:
    for i in range(1,int(n**0.5)+1):
        if(n%i==0):
            listaDiv.append(i)
            listaDiv.append(int(n/i))
    print(n,'tiene ' ,len(listaDiv), 'divisores: ',sorted(listaDiv))
    
