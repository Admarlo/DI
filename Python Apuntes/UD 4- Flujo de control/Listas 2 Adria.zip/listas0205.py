#Escriba un programa que calcule términos de la sucesión del tipo:
#U(n+1)=3*U(n)+1 si es impar
#U(n+1)=U(n)/2 si U(n) es par.
#El programa tiene que pedir el término U(0) y el número de términos a calcular.

print('Cálculos de términos de sucesión:')
print('U(n+1)=3*U(n)+1\n si n es impar')
print('U(n+1)=U(n)/2\n si n es par')
u0=int(input('Dígame el valor de U(0): '))
n=int(input('Dígame cuantos términos quiere: '))

sucesion=list()
pivote=1

while (u0!=1|pivote<n):
    sucesion.append(u0)
    if(u0%2==0):
        u0/=2
    else:
        u0=u0*3+1
    pivote+=1
sucesion.append(u0)
print('Los términos de la sucesión son: ',sucesion)
