#Escriba un programa que calcule términos de la sucesión del tipo: U(n+1)=a*U(n)+b
#El programa tiene que pedir el valor de a, de b y el tèrmino U(0) y el número de
#términos a calcular.

#Escritura de la sucesión y petición de los valores.
print('Cálculo de términos de una sucesión: U(n+1)=a*U(n)+b')
a=int(input('Dígame el valor de a: '))
b=int(input('Dígame el valor de b: '))
u0=int(input('Dígame el valor de U(0): '))
n=int(input('Dígame cuantos términos: '))
#Creación de la lista que contendra los valores de la sucesión.
sucesion=list()
#Inserción en la lista de los valores u(0) y del resto de términos, mediante el
#uso del búcle for para controlar los términos requeridos.
sucesion.append(u0)
for i in range(n-1):
#Calculo de la sucesión e insersión en la lista
    sucesion.append(a*(sucesion[i])+b)

#Visualización de la lista     
print('Los términos de la sucesión son: ',sucesion)
