#Escriba un programa que pida un número y a continuación escriba la lista de todos
#los números primos hasta él

#petición del número y creación de la lista
n=int(input('Déme un número: '))
listaPrim=list()
listaFinal=list()
if(n<0):
      print("El número insertado tiene que ser mayor de cero")
else:
#Recorrido desde 1 hasta el número introducido para el cálculo de los números
#primos y almacenamiento en la lista a mostrar
    for i in range(1,n):
        for x in range(2,i):
            if(n%x)==0:
                listaPrim.append(i)
    for i in listaPrim:
        if i in listaFinal:
            continue
        listaFinal.append(i)
print('Primos hasta '+str(n)+' : ',listaFinal)
            
