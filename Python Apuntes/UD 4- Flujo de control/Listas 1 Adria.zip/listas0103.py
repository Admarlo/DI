#Escriba un programa que permita crear una lista de palabras y que, a continuación, pida dos
#palabras y sustituya la primera por la segunda en la lista.

#Creo la lista
l=input("Dígame cuantas palabras tiene la lista ")
lista=list()
#En caso que la el número de valores de la lista sea inferior a 1 la lista no se
#podrá rellenar
if(int(l)<=0):
    print("¡Imposible!")
else:
#En caso contrario, recorremos la lista introduciendo las palabras
    for i in range(int(l)):
          introduce=input('Dígame la palabra '+str(i+1)+': ')
          lista.append(introduce)
#Visualizamos la lista y pedimos la palabra de cambio
    print('La lista creada es:',lista)
    palabra=input('Dígame la palabra a sustituir: ')
    print('Sustituir la palabra: '+palabra)
    sustituir=input('por la palabra: ')
    print('en la lista se cambiara '+palabra+' por '+sustituir)
#volvemos a recorrer la lista para encontrar la palabra a cambiar,
#sin tener en cuenta la posición que ocupa la palabra a cambiar.
    for i, introduce in enumerate(lista):        
        if(introduce==palabra):
            lista[i]=sustituir
#Visualizamos la lista con su respectivo cambio.
print('La lista es ahora: ',lista)
