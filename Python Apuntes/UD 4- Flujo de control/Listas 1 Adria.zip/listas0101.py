#Escriba un programa que permita crear una lista de palabras. Para ello, el programa tiene que
#pedir un número y luego solicitar ese número de palabras para crear la lista. Por último, el
#programa tiene que escribir la lista.

#Introduzco y creo la lista demandada
l=input("Dígame el número de palabras de la lista ")
lista=list()
#Para controlar que la creación de la lista sea la correcta, evaluo, mediante un
#búcle if la longuitud de caracteres que usuario quiere añadir, conviertiendolo a entero
if(int(l)<=0):
    print("¡Imposible!")
else:
#Si la evaluación es buena, ya podemos entroducirle el número de palabras
    for i in range(int(l)):
          introduce=input('Dígame la palabra a introducir '+str(i+1)+': ')
          lista.append(introduce)
#De esta forma visualizamos la lista completa          
print('La lista creada es:',lista)
