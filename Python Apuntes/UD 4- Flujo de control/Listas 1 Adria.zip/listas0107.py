#escriba un programa que permita crear unas listas de palabras y que, a continuación
#elimine los elementos repetidos (dejando únicamente el primero de los elementos
#repetidos

#Creación y adición de las palabras en la lista
l=input('Dígame cuántas palabras tiene la lista: ')
lista=list()
if(int(l)<=0):
    print('¡Imposible!')
else:
    for i in range(int(l)):
        introduce=input('Dígame la palabra '+str(i+1)+' : ')
        lista.append(introduce)
print("La lista creada es: ",lista)
#Creo una lista2
lista2=[]
#Recorriendo la lista1
for i in lista:
#Se encuentra algún término repetido que no lo añada a la lista2
    if i in lista2:
        continue
    lista2.append(i)
#visualización de la lista2
print("La lista inversa es: ",lista2)
