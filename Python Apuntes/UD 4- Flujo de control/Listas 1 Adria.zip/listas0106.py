#Escriba un programa que permita crear una lista de palabras y que, a continuación,
#cree una segunda lista igual a la primera, pero al revés (no se trata de escribir
#la lista al revés, sino de crear una lista distinta)

#Creación y adición de nombres en la lista.
l=input('Dígame cuantas palabras tiene la lista: ')
lista=list()
if(int(l)<=0):
    print('¡Imposible!')
else:
    for i in range(int(l)):
        introduce=input('Dígame la palabra '+str(i+1)+' :')
        lista.append(introduce)
print('La lista creada es: ',lista)
#utilizo el método reversad para iteraciones, y se lo añado a la lista nueva
lista2=list(reversed(lista))
print('La lista inversa es: ',lista2)
