#Escriba un programa que permita crear dos listas de palabras y que, a
#continuación, elimine de la primera lista los nombres de la segunda lista.

#Creación y adición de nombres de la lista1.
l1=input('Digame cuántas palabras tiene la lista: ')
lista1=list()
if(int(l1)<=0):
    print('¡Imposible!')
else:
    for i in range(int(l1)):
        introduce1=input('Dígame la palabra '+str(i+1)+' : ')
        lista1.append(introduce1)
print('La lista creada es: ',lista1)
#Creación y adición de nombres de la lista2.
l2=input('Dígame cuántas palabras tiene la lista de palabras a eliminar: ')
lista2=list()
if(int(l2)<=0):
    print('¡Imposible!')
else:
    for i in range(int(l2)):
        introduce2=input('Dígame la palabra '+str(i+1)+' :')
        lista2.append(introduce2)
    print('La lista de palabras a eliminar es: ',lista2)
#Recorro las dos listas comparandolas, para eliminar la lista2 de la lista1
    listaFinal=[i for i in lista1 if i not in lista2]
#visualización de la lista, una vez eliminado los términos de la lista2
print('La lista es ahora: ',listaFinal)

