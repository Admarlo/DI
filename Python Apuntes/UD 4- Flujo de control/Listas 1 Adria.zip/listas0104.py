#Escriba un programa que permita crear una lista de palabras y que, a continuación,
#pida una palabra y elimine esa palabra de la lista.

#Creo la lista
l=input('Dígame cuántas palabras tiene la lista: ')
lista=list()
#En caso que la el número de valores de la lista sea inferior a 1 la lista no se
#podrá rellenar
if(int(l)<=0):
    print("¡Imposible!")
else:
#En caso contrario, recorremos la lista introduciendo las palabras
    for i in range(int(l)):
        introduce=input('Dígame la palabra '+str(i+1)+' :')
        lista.append(introduce)
#Visualizamos la lista y pedimos la palabra a eliminar
print('La lista creada es:',lista)
palabra=input('Palabra a eliminar: ')
#Eliminamos el término introducido
introduce==palabra
lista.remove(palabra)
#Visualizamos la lista de nuevo, pero sin el término eliminado
print('La lista es ahora: ',lista)

