#Escriba un programa que permita creas dos listas de palabras y que, a continuación
#escriba las siguientes listas (en las que no debe haber repeticiones)
    #Listas de palabras que aparecen en las dos listas
    #Listas de palabras que aparecen en la primera lista, pero no en la segunda
    #Listas de palabras que aparecen en la segunda lista, pero no en la primera
    #Listas de palabras que aparecen en ambas listas

l1=input("Dígame cuántas palabras tiene la primera lista: ")
lista1=list()
if (int(l1)<=0):
    print("¡Imposible")
else:
    for i in range(int(l1)):
         introduce=input("Dígame la palabra "+str(i+1)+" :")
         lista1.append(introduce)
print('La lista creada es: ',lista1)
l2=input('Dígame cuantas palabras tiene la segunda lista:')
lista2=list()
if(int(l2)<=0):
    print('¡Imposible!')
else:
    for i in range(int(l2)):
         introduce2=input('Digame la palabra '+str(i+1)+' :')
         lista2.append(introduce2)
print('La segunda lista es: ',lista2)
#Comparamos las dos listas y lo almacenamos en una listaComun
listaComun=[i for i in lista1 if i in lista2]
print("Palabras que aparecen en las dos listas:",listaComun)
lista1Si=[i for i in lista1 if i not in lista2]
#Evaluo las dos listas y me que solo las que aparecen en lista1
print("Palabras que sólo aparecen en la primera lista: ", lista1Si)
lista2Si=[i for i in lista2 if i not in lista1]
#La misma expresión que antes, pero me quedo con las que sólo en la segunda lista
print("Palabras que sólo aparecen en la segunda lista: ", lista2Si)
#Para extraer todas las palabras si repetir, creo lista nueva, y mediante dos búcles
#recorro las cadenas existentes, lista1 y lista2, para 
#añadir las palabras que no esté, contenidas en la nueva lista.
listaTodas=[]
for i in lista1:
    if i not in listaTodas:
        listaTodas.append(i)
for i in lista2:
    if i not in listaTodas:
        listaTodas.append(i)
print("Todas las palabras: ",listaTodas)

