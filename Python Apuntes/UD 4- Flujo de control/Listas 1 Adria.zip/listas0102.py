#Escriba un programa que permita crear una lista de palabras y que, a continuación, pida una
#palabra y diga cuántas veces aparece esa palabra en la lista.

l=input("Dígame cuantas palabras tiene la lista ")
lista=list()
if(int(l)<=0):
    print("¡Imposible!")
else:
    for i in range(int(l)):
          introduce=input('Dígame la palabra '+str(i+1)+': ')
          lista.append(introduce)
    print('La lista creada es:',lista)
    for i in range(int(l)):
        palabra=input('Dígame la palabra a buscar: ')
        veces=lista.count(palabra)
        if(palabra not in lista):
            print('La palabra '+palabra+' no está en la lista')
        elif(veces==1):
            print('La palabra '+palabra+' aparece '+str(veces)+' sola vez')
        else:
            print('La palabra '+palabra+' aparece '+str(veces)+' veces en la lista.')
        break
